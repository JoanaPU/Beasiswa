<body bgcolor="White">
<h1><p align="center">
<font color="black">
   	Sistem Pendukung Keputusan Beasiswa<br>
	Universitas Kristen Duta Wacana<br>
	Metode Simple Additive Weighting (SAW)
</h1> 
</b>
</p>
</font>